<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="themes/5/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/5/js-image-slider.js" type="text/javascript"></script>
    <link href="generic.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />
    <script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
</head>

<link rel="stylesheet" type="text/css" href="style.css" />

<body>
<div style="position:fixed;left:0;bottom:240px;width:37px;z-index:1000;">
  <img src="images/phoneno.jpg" />
</div>
<div style="position:fixed;right:0;bottom:20px;width:37px;z-index:1000; margin-right:15px;">
<a href="#">  <img src="images/facebook1.png" /></a>
</div>
<div style="position:fixed;right:0;bottom:75px;width:37px;z-index:1000; margin-right:15px;">
<a href="#">  <img src="images/google1.png" /></a>
</div>
<div style="position:fixed;right:0;bottom:130px;width:37px;z-index:1000; margin-right:15px;">
<a href="#">  <img src="images/digg1.png" /></a>
</div>
<div style="position:fixed;right:0;bottom:185px;width:37px;z-index:1000; margin-right:15px;">
<a href="#">  <img src="images/delicious1.png" /></a>
</div>
<div style="position:fixed;right:0;bottom:240px;width:37px;z-index:1000; margin-right:15px;">
<a href="#">  <img src="images/twitter1.png" /></a>
</div>
<div class="container">
<div class="header"><img src="images/logo.png" width="140" style="margin-top:6px; margin-left:10px;" height="145px;" />
  <div class="orgname" ><a style="text-decoration:none" href="index.php?Result&pag"><h1>SURYODAYA HIGHER SECONDARY </h1>
  <h2>ENGLISH BOARDING SCHOOL</h2></a>
<div class="slogan"><h3>In Persuit Of Knowledge....</h3></div>
  </div>
<div style="position: absolute; height: 78px; width: 177px; left: 1039px; top: 54px; right: 2px;"><form name="searchform" method="get" action="search.php?Result">
                <table width="175" height="94">
                    <tbody>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2"><input type="text" maxlength="300" size="23" name="q" style="color:#999;" value="Search......" onblur="if(this.value=='') this.value='Search......';" onfocus="if(this.value=='Search......') this.value='';"/></td>
                        </tr>
                        <tr>
                            <td align="right" width="25">
                            <div align="left"><span style="color: rgb(204, 255, 204);"><input type="submit" name="submit" value="Go" /></span></div> 
                            </td>
                        </tr>
                    </tbody>
                </table>
    </form> </div>
  <div class="menu">
  <ul>
    <li><a href="index.php?pag=1&Result">Home</a></li>
    <li><a id="current" href="#">Management</a>
    <ul>
        <li><a href="readmore.php?pag=2&Result">From Principal's Desk</a></li>
        <li><a href="readmore.php?pag=13&Result">Director's Message</a></li>
        <li><a href="readmore.php?pag=12&Result">Faculty Members</a></li>
        <li><a href="readmore.php?pag=3&Result">Our Services</a></li>
        <li><a href="readmore.php?pag=4&Result">Faculties</a></li>

    </ul>
    </li>
    <li><a id="current" href="readmore.php?pag=6&Result">Admission</a>
    <ul>
        <li><a href="readmore.php?pag=5&Result">Rules for admission</a></li>
        <li><a href="readmore.php?pag=6&Result">Fees and fines</a></li>
    </ul>
    </li>
    <li><a id="current" href="gal.php?Result">Photo Gallery</a>  </li>
    
     <li><a id="current" href="readmore.php?pag=6&Result">About Us</a>
    <ul>
    	<li><a href="readmore.php?pag=1&Result">Introduction</a></li>
        <li><a href="readmore.php?pag=7&Result">Why Suryodaya?</a></li>
        <li><a href="readmore.php?pag=8&Result">Student facilities</a></li>
        <li><a href="readmore.php?pag=9&Result">Scholarship scheme</a></li>
        <li><a href="readmore.php?pag=10&Result">Rules and regulations</a></li>
    </ul>
    </li>
    
    <li><a id="current" href="readmore.php?pag=11&Result">Contact Us</a>   </li>
    <li><a id="current" href="feedback.php?Result&msg">Feedback Us</a>   </li>
     
    
    <li>&nbsp;</li>
</ul>
  </div>
  
  <!-- end .header --></div>
  <div class="sidebar1">
   <div class="side">
   <h3>Quick Links</h3>
   
    <ul class="nav">
<li><a href="index.php?pag=1&Result">Home</a></li>
      <li><a href="gal.php?Result">Photo Gallery</a></li>
      <li><a href="download.php?Result&selectnote=All">Download Notes</a></li>
      <li><a href="admin.php?key=123&Result" target="_blank">Login</a></li>
      <li><a href="http://slc.ntc.net.np/" target="_blank" >SLC Result</a></li>
      <li><a href="http://hseb.ntc.net.np/" target="_blank">HSEB Result</a></li>
      <li><a href="http://www.hseb.edu.np/" target="_blank">HSEB Board</a></li>    </ul>
    </div>
   <!-- end .sidebar1 -->
   <br />
  <iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FSuryodaya-HSEBS-Kakarvitta%2F213109858825143&amp;width=190&amp;height=290&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;border_color&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:190px; height:290px;" allowTransparency="true"></iframe>
   </div>
    
    
   
  <div class="content">
  <h3 style="text-align:center; color:#C09; font-size:30px; font-family:'monotype Corsiva';">Here, you can download school level, +2 level and other reference notes....</h3>
  <img src="images/download.gif" style="margin-left:290px;"/>
 <form name="selectt" method="get" action="">
<table>
<tr><th align="left" style="color:#06F;">Select Category</th>
      <td><label>
        <select name="selectnote" class="style9" onchange="javascript:this.form.submit();">
       <option <?php if($_REQUEST['selectnote']=='All'){echo'selected="selected"';}?>>All</option>
          <option <?php if($_REQUEST['selectnote']=='Class XI'){echo'selected="selected"';}?>>Class XI</option>
          <option <?php if($_REQUEST['selectnote']=='Class XII'){echo'selected="selected"';}?>>Class XII</option>
          <option <?php if($_REQUEST['selectnote']=='School Level'){echo'selected="selected"';}?>>School Level</option>
          <option <?php if($_REQUEST['selectnote']=='Extra'){echo'selected="selected"';}?>>Extra</option>
        </select>
      </label></td></tr>
    </table>
      </form>
      <style>
	  .head{
		  color:#06F;
		  margin-left:40px;
		  text-decoration:underline;
	  }
	  </style>
     
      <br />
<?PHP
include('conn.php');
if($_REQUEST['selectnote']=='Class XI')
{
$sql = "SELECT COUNT(*) FROM notes where category='Class XI'";
}
if($_REQUEST['selectnote']=='Class XII')
{
$sql = "SELECT COUNT(*) FROM notes where category='Class XII'";
}
if($_REQUEST['selectnote']=='School Level')
{
$sql = "SELECT COUNT(*) FROM notes where category='School Level'";
}
if($_REQUEST['selectnote']=='Extra')
{
$sql = "SELECT COUNT(*) FROM notes where category='Extra'";
}
if($_REQUEST['selectnote']=='All')
{
$sql = "SELECT COUNT(*) FROM notes";
}
$result = mysql_query($sql) or trigger_error("SQL", E_USER_ERROR);
$r = mysql_fetch_row($result);
$numrows = $r[0];
// number of rows to show per page
$rowsperpage = 10;
// find out total pages
$totalpages = ceil($numrows / $rowsperpage);

// get the current page or set a default
if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage'])) {
   // cast var as int
   $currentpage = (int) $_GET['currentpage'];
} else {
   // default page num
   $currentpage = 1;
} // end if

// if current page is greater than total pages...
if ($currentpage > $totalpages) {
   // set current page to last page
   $currentpage = $totalpages;
} // end if
// if current page is less than first page...
if ($currentpage < 1) {
   // set current page to first page
   $currentpage = 1;
} // end if

// the offset of the list, based on current page 
$offset = ($currentpage - 1) * $rowsperpage;

// get the info from the db 
if($_REQUEST['selectnote']=='Class XI')
{
$sql = "SELECT * FROM notes where category='Class XI' order by id desc LIMIT $offset, $rowsperpage";
}
if($_REQUEST['selectnote']=='Class XII')
{
$sql = "SELECT * FROM notes where category='Class XII' order by id desc LIMIT $offset, $rowsperpage";
}
if($_REQUEST['selectnote']=='School Level')
{
$sql = "SELECT * FROM notes where category='School Level' order by id desc LIMIT $offset, $rowsperpage";
}
if($_REQUEST['selectnote']=='Extra')
{
$sql = "SELECT * FROM notes where category='Extra' order by id desc LIMIT $offset, $rowsperpage";
}
if($_REQUEST['selectnote']=='All')
{
$sql = "SELECT * FROM notes order by id desc LIMIT $offset, $rowsperpage";
}
$result = mysql_query($sql) or trigger_error("SQL", E_USER_ERROR);
echo "<h3 class=head>"."$_REQUEST[selectnote]"."</h3>";
echo "<table align=center border=1 bgcolor=#CC33CC bordercolor=#FFFFFF width=800>";
echo "<tr><th>Download List</th></tr>";
while ($list = mysql_fetch_assoc($result)) {
   // echo data
echo "<tr>";
echo '<td><a style="margin-left:250px;" href='.$list['location'].' target=_blank><ul><li>'.$list['caption'].'</li></ul></a></td>';
echo "</tr>";
}
echo "</table>";
//   echo $list['location'] . " : " . $list['caption'] . "<br />";
 // end while

/******  build the pagination links ******/
// range of num links to show
$range = 3;
echo"<br/>";
// if not on page 1, don't show back links
if ($currentpage > 1) {
   // show << link to go back to page 1
   echo " <a href='{$_SERVER['PHP_SELF']}?currentpage=1&err&selectnote=$_REQUEST[selectnote]'><<</a> ";
   // get previous page num
   $prevpage = $currentpage - 1;
   // show < link to go back to 1 page
   echo " <a href='{$_SERVER['PHP_SELF']}?currentpage=$prevpage&err&selectnote=$_REQUEST[selectnote]'><</a> ";
} // end if 

// loop to show links to range of pages around current page
for ($x = ($currentpage - $range); $x < (($currentpage + $range) + 1); $x++) {
   // if it's a valid page number...
   if (($x > 0) && ($x <= $totalpages)) {
      // if we're on current page...
      if ($x == $currentpage) {
         // 'highlight' it but don't make a link
         echo "<font color=#FF0000> [<b>$x</b>]</font> ";
      // if not current page...
      } else {
         // make it a link
         echo " <a href='{$_SERVER['PHP_SELF']}?currentpage=$x&err&selectnote=$_REQUEST[selectnote]'>$x</a> ";
      } // end else
   } // end if 
} // end for
                 
// if not on last page, show forward and last page links        
if ($currentpage != $totalpages) {
   // get next page
   $nextpage = $currentpage + 1;
    // echo forward link for next page 
	if($totalpages!=0)
	{
   echo " <a href='{$_SERVER['PHP_SELF']}?currentpage=$nextpage&err&selectnote=$_REQUEST[selectnote]'>></a> ";
   // echo forward link for lastpage
   echo " <a href='{$_SERVER['PHP_SELF']}?currentpage=$totalpages&err&selectnote=$_REQUEST[selectnote]'>>></a> ";}
} 
?>
 <hr />
  <div>

  
<h3 style="color: #CCC; font-style: italic; font-family: 'monotype Corsiva'; width: 113px; background: #3B5998; font-size: 20px; padding:0px; ">Share us with</h3>
 <table width="200" style="margin:0px; padding:0px;">
  <tr>
 <td><a href="#"> <img src="images/facebook.png" /></a></td>
 <td><a href="#"><img src="images/google.png" /></a></td>
 <td><a href="#"> <img src="images/twitter.png" /></a></td>
 <td><a href="#"> <img src="images/digg.png" /></a></td>
 <td><a href="#"><img src="images/linkedin.png" /></a></td>
  </tr>
  </table>
  
  </div>
   
    <!-- end .content --></div>
  
  <div class="footer">
  <div class="footerlink">
    <table width="200" border="0" class="ftab1">
      <tr>
        <th> Quick Links</th>
      </tr>
      <tr>
        <td><a href="http://www.facebook.com/pages/Suryodaya-HSEBS-Kakarvitta/213109858825143" target="_blank">Facebook</a></td></tr>
        <tr><td><a href="feedback.php?Result&msg">Feedback Us!</a></td></tr>
        <tr><td><a href="#">Sitemap!</a></td></tr>
        <tr><td><a href="download.php?Result&selectnote=All">Download!</a></td></tr>
        <tr><td><a href="#">Calender</a></td></tr>
    </table>
    <table width="200" border="0" class="ftab2">
      <tr>
        <th> About Us</th>
      </tr>
        <tr><td><a href="readmore.php?pag=1">Introduction</a></td></tr>
        <tr><td><a href="readmore.php?pag=12">Faculty Members</a></td></tr>
        <tr><td><a href="readmore.php?pag=7">Our Features</a></td></tr>
        <tr><td><a href="readmore.php?pag=9">Scholarship Scheme</a></td></tr>
        <tr><td><a href="readmore.php?pag=11">Contact Us</a></td></tr>
    </table>
    
     <table width="200" border="0" class="ftab3">
      <tr>
        <th> Visitor's Counter</th>
      </tr>
        <tr><td><a href="#">Facilities</a></td></tr>
    </table>
    
  </div>
  <hr />
  <div style="background:#C03; height:60px; margin-bottom:-10px; margin-top:-7px;">
    <p>Suryodaya HSEBS, Mechinagar-10, Jhapa, Nepal Phone:- 00977-023-562676</p>
           <p>Copyright&copy;2012 suryodaya.edu.np by Webmaster <a href="http://www.arunupadhayay.com.np" target="_blank">Arun Kumar Upadhyay</a></p>
    <!-- end .footer --></div>
  <!-- end .container --></div>
</body>
</html>